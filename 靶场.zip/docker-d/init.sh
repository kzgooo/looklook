#!/bin/bash
# ============================================================
# 电脑D：出网主机（仅与B互通，与C不互通）
# 攻击链：SSH登录普通用户 → 利用脆弱cron任务提权 → 拿下root
# 入口：由B横向移动 SSH 登录 D
# ============================================================
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[D] 更新软件源..."
apt-get update -y || echo "[D] apt update失败(继续)"

echo "[D] 安装工具(openssh-server apache2 php cron curl)..."
DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server apache2 php cron curl net-tools iproute2 || echo "[D] 安装部分失败"

for i in $(seq 1 30); do
    [ -f /etc/ssh/sshd_config ] && break
    sleep 1
done

echo "[D] 配置SSH(禁止root直接登录, 只允许普通用户)..."

# 创建普通用户 userd
useradd -m -s /bin/bash userd 2>/dev/null || true
echo "userd:passd123" | chpasswd

# 允许userd登录, 禁止root登录(需提权)
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin no/' /etc/ssh/sshd_config
echo "PermitRootLogin no" >> /etc/ssh/sshd_config
echo "AllowTcpForwarding yes" >> /etc/ssh/sshd_config
# 确保root密码存在但不允许登录
echo "root:rootd" | chpasswd
mkdir -p /run/sshd
/usr/sbin/sshd 2>/dev/null || true

echo "[D] 启动Apache..."
service apache2 start 2>/dev/null || true

echo "[D] 创建root的Flag(需提权才能读)..."
mkdir -p /root
echo "FLAG{D_CRON_PRIVESC_OK}" > /root/flag.txt
chmod 600 /root/flag.txt
chown root:root /root/flag.txt

echo "[D] 部署脆弱cron任务(backup.sh 普通用户可写, 以root每分钟执行)..."
mkdir -p /usr/local/bin
cat > /usr/local/bin/backup.sh <<'SHEOF'
#!/bin/bash
# 备份脚本(以root运行)
cp /etc/hostname /tmp/backup_hostname.txt 2>/dev/null
SHEOF
chmod 777 /usr/local/bin/backup.sh   # 普通用户可写 -> 可提权
chown root:root /usr/local/bin/backup.sh

# 添加cron任务
mkdir -p /etc/cron.d
echo "* * * * * root /usr/local/bin/backup.sh >/dev/null 2>&1" > /etc/cron.d/backup
chmod 644 /etc/cron.d/backup
# 启动cron
service cron start 2>/dev/null || cron 2>/dev/null || true

echo "[D] 部署Web Flag校验页面..."
cat > /var/www/html/index.php <<'PHPEOF'
<?php
echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>电脑D</title></head><body>";
echo "<h2>电脑D - 出网主机</h2>";
echo "<p>root的Flag在 /root/flag.txt (需要提权才能读取)</p>";
echo "<p>尝试从普通用户 <b>userd</b> 登录, 利用cron提权到root</p>";
echo "</body></html>";
PHPEOF

cat > /var/www/html/flag.php <<'PHPEOF'
<?php
$correct = "FLAG{D_CRON_PRIVESC_OK}";
$msg = "";
if(isset($_GET['flag'])){
    if(trim($_GET['flag']) === $correct){
        $msg = "<div style='color:green;font-size:24px;'>✓ 正确! 电脑D 提权成功!</div>";
    } else {
        $msg = "<div style='color:red;font-size:24px;'>✗ 错误, 再试试</div>";
    }
}
echo "<h2>电脑D Flag 校验</h2>";
echo "<p>提权到root后执行 <code>cat /root/flag.txt</code> 获取Flag, 填入下方校验:</p>";
echo "<form method='GET' action=''><input name='flag' size='50' placeholder='输入Flag'><input type='submit' value='校验'></form>";
echo $msg;
PHPEOF

rm -f /var/www/html/index.html 2>/dev/null || true
service apache2 reload 2>/dev/null || true

echo "[D] 初始化完成. 内网IP: $(hostname -I)"
echo "[D] SSH用户: userd:passd123 (root直登被禁, 需提权)"
echo "[D] Cron提权点: /usr/local/bin/backup.sh (每分钟root执行, 用户可写)"
echo "[D] Flag: /root/flag.txt (提权后读取)"

tail -f /dev/null