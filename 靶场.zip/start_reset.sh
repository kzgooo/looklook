#!/bin/bash
# ============================================================
# 靶场一键恢复脚本
# 用法:
#   ./start_reset.sh start    一键启动靶场（已存在容器则直接启动）
#   ./start_reset.sh reset    一键重置靶场（删除全部容器并重建）
#   ./start_reset.sh status   查看靶场状态
#   ./start_reset.sh stop     停止全部靶场容器
#   ./start_reset.sh down     停止并删除全部靶场容器
# ============================================================
set -e

cd "$(dirname "$0")"

COMPOSE="docker-compose.yml"
PROJECT="labrange"
CONTAINERS="web-b target-c host-d target-f"
NETWORKS="outnet b-c b-d c-f"

usage() {
    echo "用法: $0 {start|reset|status|stop|down}"
    echo "  start   一键启动靶场(容器存在则直接启动, 不存在则创建)"
    echo "  reset   一键重置靶场(删除全部容器与网络, 重建初始环境)"
    echo "  status  查看靶场运行状态"
    echo "  stop    停止全部容器"
    echo "  down    停止并删除全部容器与网络"
}

# 等待容器就绪
wait_ready() {
    local c=$1
    echo "  [等待] $c 初始化..."
    for i in $(seq 1 60); do
        if docker exec "$c" sh -c "ls /init.sh >/dev/null 2>&1" 2>/dev/null; then
            echo "  [OK] $c 已就绪"
            return 0
        fi
        sleep 1
    done
    echo "  [WARN] $c 初始化超时(可能仍在apt安装, 可稍后查看)"
    return 1
}

# 打印拓扑信息
print_topology() {
    echo ""
    echo "====================================================="
    echo "  靶场已就绪 - 拓扑信息"
    echo "====================================================="
    echo "  电脑B (Web服务器/中心枢纽, 出网)"
    echo "    Web : http://127.0.0.1:8080   (命令注入漏洞点)"
    echo "    SSH : ssh root@127.0.0.1 -p 2222  (密码: toor123)"
    echo "    内网: 172.30.0.10(outnet) 172.31.0.10(b-c) 172.32.0.10(b-d)"
    echo ""
    echo "  电脑C (内网主机, 不出网, 与B/F互通, 与D不互通)"
    echo "    内网: 172.31.0.20(b-c) 172.33.0.20(c-f)"
    echo "    SSH : root:rootc   (仅能通过B跳板访问)"
    echo "    Web : 172.31.0.20   (Flag1: FLAG{C_INTRANET_ACCESS_OK})"
    echo ""
    echo "  电脑D (出网主机, 仅与B互通, 与C不互通)"
    echo "    内网: 172.32.0.30(b-d)"
    echo "    SSH : root:rootd   (仅能通过B跳板访问)"
    echo "    Web : 172.32.0.30   (Flag2: FLAG{D_OUTBOUND_HOST_OK})"
    echo ""
    echo "  电脑F (最深内网, 不出网, 仅与C互通)"
    echo "    内网: 172.33.0.40(c-f)"
    echo "    Web : 172.33.0.40   (Final: FLAG{F_DEEPEST_NETWORK_REACHED})"
    echo ""
    echo "  链路: A -> B -> C -> F   (三级跳板)"
    echo "        A -> B -> D        (横向移动分支)"
    echo "====================================================="
}

cmd_start() {
    echo "[1/3] 检查是否存在靶场容器..."
    if docker inspect "$(echo $CONTAINERS | awk '{print $1}')" >/dev/null 2>&1; then
        echo "  检测到容器已存在, 直接启动..."
        docker start $CONTAINERS
    else
        echo "  未检测到容器, 从compose创建..."
        docker compose -p "$PROJECT" -f "$COMPOSE" up -d
    fi
    echo "[2/3] 等待各容器初始化完成..."
    for c in $CONTAINERS; do
        wait_ready "$c"
    done
    echo "[3/3] 完成!"
    print_topology
}

cmd_reset() {
    echo "[1/4] 停止并删除全部靶场容器..."
    docker compose -p "$PROJECT" -f "$COMPOSE" down --remove-orphans 2>/dev/null || docker rm -f $CONTAINERS 2>/dev/null || true
    echo "[2/4] 清理残留网络..."
    for n in $NETWORKS; do
        docker network rm "$n" 2>/dev/null || true
    done
    echo "[3/4] 重建靶场环境..."
    docker compose -p "$PROJECT" -f "$COMPOSE" up -d
    echo "[4/4] 等待各容器初始化完成..."
    for c in $CONTAINERS; do
        wait_ready "$c"
    done
    echo "  >>> 环境已重置为初始状态!"
    print_topology
}

cmd_status() {
    echo "========== 容器状态 =========="
    docker ps -a --filter "name=web-b" --filter "name=target-c" --filter "name=host-d" --filter "name=target-f" \
        --format "表: {{.Names}}\t状态: {{.Status}}\t端口: {{.Ports}}"
    echo ""
    echo "========== 网络状态 =========="
    for n in $NETWORKS; do
        if docker network inspect "$n" >/dev/null 2>&1; then
            echo "  $n : 已创建"
        else
            echo "  $n : 不存在"
        fi
    done
}

cmd_stop() {
    echo "停止全部靶场容器..."
    docker stop $CONTAINERS
    echo "已停止."
}

cmd_down() {
    echo "停止并删除全部靶场容器与网络..."
    docker compose -p "$PROJECT" -f "$COMPOSE" down --remove-orphans
    echo "已清理."
}

case "${1:-}" in
    start)   cmd_start ;;
    reset)   cmd_reset ;;
    status)  cmd_status ;;
    stop)    cmd_stop ;;
    down)    cmd_down ;;
    *)       usage ;;
esac