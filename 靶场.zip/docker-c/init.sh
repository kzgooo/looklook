#!/bin/bash
# ============================================================
# 电脑C：内网主机（不出网，与B/F互通，与D不互通）
# 攻击链：SQL注入 → 后台命令执行(RCE) → 拿下C
# 入口：由B横向移动访问 C 的 login.php
# ============================================================
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[C] 更新软件源..."
apt-get update -y || echo "[C] apt update失败(继续)"

echo "[C] 安装工具(apache2 php php-sqlite3 sqlite3 ssh curl)..."
DEBIAN_FRONTEND=noninteractive apt-get install -y apache2 php php-sqlite3 sqlite3 openssh-server curl net-tools iproute2 || echo "[C] 安装部分失败"

for i in $(seq 1 30); do
    [ -f /etc/ssh/sshd_config ] && break
    sleep 1
done

echo "[C] 配置SSH root密码认证..."
mkdir -p /run/sshd
echo "root:rootc" | chpasswd
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
echo "AllowTcpForwarding yes" >> /etc/ssh/sshd_config
/usr/sbin/sshd 2>/dev/null || true

echo "[C] 启动Apache..."
service apache2 start 2>/dev/null || true

echo "[C] 建立SQLite数据库..."
mkdir -p /var/www/db
sqlite3 /var/www/db/users.db <<'SQLEOF'
CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT);
INSERT INTO users VALUES (1, 'admin', 'admin_c_secret');
INSERT INTO users VALUES (2, 'root', 'rootc');
INSERT INTO users VALUES (3, 'user', 'p@ssw0rd');
SQLEOF
chown -R www-data:www-data /var/www/db
chmod 777 /var/www/db
chmod 666 /var/www/db/users.db

echo "[C] 部署SQL注入Web..."
cat > /var/www/html/index.php <<'PHPEOF'
<?php
echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>电脑C - 内部系统登录</title></head><body>";
echo "<h1>电脑C 内部业务系统</h1>";
echo "<form method='POST' action='login.php'>";
echo "用户名: <input name='username'><br>";
echo "密码: <input type='password' name='password'><br>";
echo "<input type='submit' value='登录'>";
echo "</form>";
echo "</body></html>";
PHPEOF

cat > /var/www/html/login.php <<'PHPEOF'
<?php
$user = $_POST['username'];
$pass = $_POST['password'];
$db = new SQLite3('/var/www/db/users.db');
$sql = "SELECT * FROM users WHERE username='$user' AND password='$pass'";
$res = $db->query($sql);
$row = $res->fetchArray(SQLITE3_ASSOC);
if ($row) {
    echo "<p>登录成功, 欢迎: " . $row['username'] . "</p>";
    echo "<p><a href='admin.php'>进入管理后台</a></p>";
} else {
    echo "<p style='color:red'>登录失败</p>";
}
PHPEOF

cat > /var/www/html/admin.php <<'PHPEOF'
<?php
echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>电脑C - 管理后台</title></head><body>";
echo "<h2>电脑C 管理后台</h2>";
echo "<form method='GET' action=''><input name='cmd' placeholder='执行命令, 如: id'><input type='submit' value='执行'></form><pre>";
if(isset($_GET['cmd'])){
    system($_GET['cmd']);
}
echo "</pre>";
echo "<p>Flag文件: /var/www/html/flag.txt</p>";
echo "</body></html>";
PHPEOF

echo "FLAG{C_SQL_RCE_OK}" > /var/www/html/flag.txt
chmod 644 /var/www/html/flag.txt

cat > /var/www/html/flag.php <<'PHPEOF'
<?php
$correct = "FLAG{C_SQL_RCE_OK}";
$msg = "";
if(isset($_GET['flag'])){
    if(trim($_GET['flag']) === $correct){
        $msg = "<div style='color:green;font-size:24px;'>✓ 正确! 电脑C 攻破成功!</div>";
    } else {
        $msg = "<div style='color:red;font-size:24px;'>✗ 错误, 再试试</div>";
    }
}
echo "<h2>电脑C Flag 校验</h2>";
echo "<p>在后台执行 <code>cat /var/www/html/flag.txt</code> 获取Flag, 填入下方校验:</p>";
echo "<form method='GET' action=''><input name='flag' size='50' placeholder='输入Flag'><input type='submit' value='校验'></form>";
echo $msg;
PHPEOF

rm -f /var/www/html/index.html 2>/dev/null || true
service apache2 reload 2>/dev/null || true

echo "[C] 初始化完成. 内网IP: $(hostname -I)"
echo "[C] SQL注入点: http://172.31.0.20/login.php (注入 admin'-- 绕过)"
echo "[C] 后台: http://172.31.0.20/admin.php (命令执行)"

tail -f /dev/null