#!/bin/bash
# ============================================================
# 电脑B：Web服务器（中心枢纽，出网，与C/D互通）
# 提供SSH(动态隧道) + Web(命令注入漏洞) + 内网探测工具
# ============================================================
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[B] 更新软件源..."
apt-get update -y || echo "[B] apt update失败(继续尝试)"

echo "[B] 安装工具..."
DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server apache2 php libapache2-mod-php socat curl nmap net-tools iproute2 || echo "[B] 安装部分失败"

# 等待sshd_config出现(apt可能需要时间)
for i in $(seq 1 30); do
    [ -f /etc/ssh/sshd_config ] && break
    sleep 1
done

echo "[B] 配置SSH root密码认证..."
mkdir -p /run/sshd
echo "root:toor123" | chpasswd
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
sed -i 's/#PermitRootLogin no/PermitRootLogin yes/' /etc/ssh/sshd_config
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
echo "AllowTcpForwarding yes" >> /etc/ssh/sshd_config

echo "[B] 启动SSH服务..."
/usr/sbin/sshd 2>/dev/null || true

echo "[B] 启动Apache..."
service apache2 start 2>/dev/null || true

echo "[B] 部署Web命令注入漏洞页..."
mkdir -p /var/www/html
cat > /var/www/html/index.php <<'PHPEOF'
<?php
echo "<h1>欢迎来到 电脑B (Web服务器 / 中心枢纽)</h1>";
echo "<p>练习用命令注入漏洞点</p><hr>";
echo "<h2>命令注入实验</h2>";
echo "<form method='GET' action=''>";
echo "<input name='cmd' placeholder='输入命令, 如: id'>";
echo "<input type='submit' value='执行'>";
echo "</form><pre>";
if(isset($_GET['cmd'])){
    system($_GET['cmd']);
}
echo "</pre>";
echo "<hr><h2>内网信息</h2><pre>";
system("hostname -I; echo '---'; cat /etc/hosts");
echo "</pre>";
PHPEOF

# B的Flag：放在web根目录，命令注入可读
echo "FLAG{B_RCE_ENTRY_OK}" > /var/www/html/flag.txt

# B的Flag校验页面
cat > /var/www/html/flag.php <<'PHPEOF'
<?php
$correct = "FLAG{B_RCE_ENTRY_OK}";
$msg = "";
if(isset($_GET['flag'])){
    $f = trim($_GET['flag']);
    if($f === $correct){
        $msg = "<div style='color:green;font-size:24px;'>✓ 正确! 电脑B 攻破成功!</div>";
    } else {
        $msg = "<div style='color:red;font-size:24px;'>✗ 错误, 再试试</div>";
    }
}
echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>B - Flag校验</title></head><body>";
echo "<h2>电脑B Flag 校验</h2>";
echo "<p>在命令注入里执行 <code>cat /var/www/html/flag.txt</code> 获取Flag, 填入下方校验:</p>";
echo "<form method='GET' action=''><input name='flag' size='50' placeholder='输入Flag'><input type='submit' value='校验'></form>";
echo $msg;
echo "</body></html>";
PHPEOF

rm -f /var/www/html/index.html 2>/dev/null || true
a2enmod php >/dev/null 2>&1 || true
service apache2 reload 2>/dev/null || true

echo "[B] 初始化完成"
echo "[B] Web: http://localhost:8080"
echo "[B] SSH: ssh root@localhost -p 2222 (密码: toor123)"
echo "[B] 内网IP: $(hostname -I)"

# 保持容器前台运行
tail -f /dev/null