#!/usr/bin/perl
# portforward.pl - TCP端口转发器
# 用法: perl portforward.pl <本地监听端口> <上游主机> <上游端口>
# 作用: 监听本地端口，把进来的连接转发到上游(通常是 host.docker.internal:9097 即Clash)
use strict;
use warnings;
use IO::Socket::INET;

my $listen_port = $ARGV[0] || 7890;
my $upstream    = $ARGV[1] || "host.docker.internal";
my $up_port     = $ARGV[2] || 9097;

my $listen = IO::Socket::INET->new(
    LocalAddr => '0.0.0.0',
    LocalPort => $listen_port,
    Listen    => 128,
    ReuseAddr => 1,
    Proto     => 'tcp',
    Timeout   => 5,
) or die "无法监听 $listen_port: $!\n";

print "转发: 0.0.0.0:$listen_port -> $upstream:$up_port\n";

while (1) {
    my $client = $listen->accept() or next;
    my $pid = fork();
    if ($pid == 0) {
        my $server = IO::Socket::INET->new(
            PeerAddr => $upstream,
            PeerPort => $up_port,
            Proto    => 'tcp',
            Timeout  => 5,
        );
        if (!$server) {
            $client->close();
            exit 0;
        }
        # 双向转发
        my $c = $client;
        my $s = $server;
        while (1) {
            my $rin = '';
            vec($rin, fileno($c), 1) = 1;
            vec($rin, fileno($s), 1) = 1;
            my $nfd = select($rin, undef, undef, 10);
            last if $nfd <= 0;
            if (vec($rin, fileno($c), 1)) {
                my $buf = '';
                my $n = sysread($c, $buf, 8192);
                last if !defined($n) || $n == 0;
                syswrite($s, $buf);
            }
            if (vec($rin, fileno($s), 1)) {
                my $buf = '';
                my $n = sysread($s, $buf, 8192);
                last if !defined($n) || $n == 0;
                syswrite($c, $buf);
            }
        }
        $c->close();
        $s->close();
        exit 0;
    }
    $client->close();
}