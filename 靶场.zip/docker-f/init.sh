#!/bin/bash
# ============================================================
# 电脑F：最深内网主机（不出网，仅与C互通）
# 攻击链：经C跳板访问 → 利用脆弱Web服务命令注入(RCE) → 拿下F
# 入口：由C横向移动访问 F 的脆弱服务
# ============================================================
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[F] 更新软件源..."
apt-get update -y || echo "[F] apt update失败(继续)"

echo "[F] 安装工具(apache2 php curl)..."
DEBIAN_FRONTEND=noninteractive apt-get install -y apache2 php curl net-tools iproute2 || echo "[F] 安装部分失败"

echo "[F] 启动Apache..."
service apache2 start 2>/dev/null || true

echo "[F] 部署脆弱Web服务(命令注入漏洞, 模拟遗留监控系统)..."
cat > /var/www/html/index.php <<'PHPEOF'
<?php
echo "<!DOCTYPE html><html><head><meta charset='utf-8'><title>电脑F - 遗留监控系统</title></head><body>";
echo "<h2>电脑F 遗留监控系统 (告警! 存在远程命令执行漏洞)</h2>";
echo "<form method='GET' action=''><input name='host' placeholder='输入主机名探测, 如: localhost'><input type='submit' value='探测'></form><pre>";
if(isset($_GET['host'])){
    system("ping -c 1 " . $_GET['host'] . " 2>&1");
}
echo "</pre>";
echo "<p>Flag文件: /var/www/html/flag.txt</p>";
echo "</body></html>";
PHPEOF

echo "FLAG{F_CVE_RCE_OK}" > /var/www/html/flag.txt
chmod 644 /var/www/html/flag.txt

cat > /var/www/html/flag.php <<'PHPEOF'
<?php
$correct = "FLAG{F_CVE_RCE_OK}";
$msg = "";
if(isset($_GET['flag'])){
    if(trim($_GET['flag']) === $correct){
        $msg = "<div style='color:green;font-size:24px;'>✓ 正确! 电脑F 攻破成功!</div>";
    } else {
        $msg = "<div style='color:red;font-size:24px;'>✗ 错误, 再试试</div>";
    }
}
echo "<h2>电脑F Flag 校验</h2>";
echo "<p>在监控系统注入 <code>cat /var/www/html/flag.txt</code> 获取Flag, 填入下方校验:</p>";
echo "<form method='GET' action=''><input name='flag' size='50' placeholder='输入Flag'><input type='submit' value='校验'></form>";
echo $msg;
PHPEOF

rm -f /var/www/html/index.html 2>/dev/null || true
service apache2 reload 2>/dev/null || true

echo "[F] 初始化完成. 内网IP: $(hostname -I)"
echo "[F] 脆弱服务: http://172.33.0.40/ (host参数命令注入)"
echo "[F] Flag: /var/www/html/flag.txt (注入读取)"

tail -f /dev/null